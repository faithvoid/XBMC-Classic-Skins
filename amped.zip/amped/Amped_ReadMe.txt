Amped.

Based on Vision for XBMC
Updated using the finest of development tecniques..  (code reuse)

If you don't like it.   I aint bothered.    If you do Great!

If you wanna help out with graphics then please contact me,  whilst I can do some I am pretty crap at it.

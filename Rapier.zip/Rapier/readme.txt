Contact: 

trizinn@gmail.com

Download:

http://xbmc.org/skins/rapier/

Support: 

http://blog.xbmc.org/forum/forumdisplay.php?f=120
---------------------------
Info
---------------------------
Skin Name: Empty
Resolution: All
Purpose: A Very Basic Skin

---------------------------
Notes/Comments
---------------------------
All screens and dialogs are labeled in red to help with identification.

.xml files were edited in Microsoft Visual C++ Express Editiion.

Enjoy -Wir3d
#-------------------------------------------------------------------------------
# Name:   	xbox.getplugin.py()
# Purpose:	To get custom shortcut plugin or script
# Author:	Dom DXecutioner
# Created:	03.25.2012
# Updated:	04.05.2012
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import xbmc
import xbmcgui
import os
import sys

# object
__window = xbmcgui.Window( xbmcgui.getCurrentWindowId() )
__dialog = xbmcgui.Dialog()
# constants
__addonPluginDefault__ = 'special://home/plugins/'
__addonScriptDefault__ = 'special://home/scripts'
# general variables
__shortcutString__ = 'home.addon.shortcut'

__addonShortcutIndex__ = sys.argv[1:][0]
__addonShortcutString__ = [ 'Xbmc.ActivateWindow(MusicLibrary,plugin://music/', 'Xbmc.ActivateWindow(Pictures,plugin://pictures/', 'Xbmc.ActivateWindow(Programs,plugin://programs/', 'Xbmc.ActivateWindow(VideoLibrary,plugin://video/' ]

def xebi(td):
	xbmc.executebuiltin( td )
		
def getScript():	
	# open the dialog window with the scripts folder as the default directory
	addonPath = __dialog.browse(0,'XBMC Script', 'files', '', False, False, __addonScriptDefault__ )
	addonFolder = os.path.basename( os.path.abspath( addonPath ) )
	# add the shortcut onclick event + "default.py"; otherwise this will fail!
	xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.name.' + __addonShortcutIndex__ + ',' + addonFolder + ')' )
	xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',Xbmc.RunScript(' + addonPath + 'default.py))' )
	xebi( 'XBMC.Skin.SetBool(' + __shortcutString__ + '.enabled.' + __addonShortcutIndex__ + ',True)' )
	# get the default icon
	getIcon( addonPath )
			
def getPlugIn():
	listAddonShortcutCategory = [ 'Music', 'Pictures', 'Programs', 'Video' ]
	# open select dialog and get user selection
	ret = __dialog.select( 'Select Addon Category', listAddonShortcutCategory )
	# test for valid selection
	if ret in (0, 1, 2, 3, 4):
		# open browse dialog with default directory based on user selection
		addonPath = __dialog.browse(0,'XBMC Plugin', 'files', '', False, False, __addonPluginDefault__ + listAddonShortcutCategory[ ret ] )
		# test for valid selection: if the path is default, notify user of cancelation; otherwise process and set the strings
		if addonPath == __addonPluginDefault__ + listAddonShortcutCategory[ ret ]:
			xebi( 'XBMC.Notification(Xbox Addon Shortcut, Addon Selection Cancelled!)' )
		else:
			addonFolder = os.path.basename( os.path.abspath( addonPath ) )
			xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.name.' + __addonShortcutIndex__ + ',' + addonFolder + ')' )
			xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',' + __addonShortcutString__[ ret ] + addonFolder + '))' )
			xebi( 'XBMC.Skin.SetBool(' + __shortcutString__ + '.enabled.' + __addonShortcutIndex__ + ',True)' )
			getIcon( addonPath )
			# assume all went well and notify user
			xebi( 'XBMC.Notification(Xbox Addon Shortcut,' + addonFolder + ' has been set!)' )
	else:
		xebi( 'XBMC.Notification(Xbox Addon Shortcut,Addon Selection Cancelled!)' )

def getIcon(path):
	listDefaultIcons = [ 'default.tbn', 'default.png' ]
	
	ret = __dialog.yesno( 'Xbox Addon Shortcut', 'Do you want to select a custom icon?', 'I think I should just test the entire thing, just in case', 'Perhaps a third line may be good idea, this way i get to see the entire feature' )
	if ret == True:
		iconPath = __dialog.browse(2, 'XBMC Plugin', 'files')
		xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',' + iconPath + ')' )
	else:
		if os.path.isfile( path + listDefaultIcons[0] ):
			xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',' + path + listDefaultIcons[0] + ')' )
		elif os.path.isfile ( path + listDefaultIcons[1] ):
			xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',' + path + listDefaultIcons[1] + ')' )

def reset():
	skinStrings = [ '.onclick.', '.icon.', '.enabled.' ]
	for skinString in skinStrings: xebi( 'XBMC.Skin.Reset(' + __shortcutString__ + skinString + __addonShortcutIndex__ + ')' )
	xebi( 'XBMC.Notification(Xbox Addon Shortcut, Shortcut ' + __addonShortcutIndex__ + ' has been reset!)' )
	
global mode
mode = -1

def main():
	# get enabled skin setting
	isEnabled = xbmc.getCondVisibility( 'Skin.HasSetting(home.addon.shortcut.enabled.' + __addonShortcutIndex__ + ')' )
	# create list for user to select addon type
	if isEnabled == True:
		listAddonType = ['Plugin', 'Script', 'Reset']
	else:
		listAddonType = ['Plugin', 'Script']
	# open select dialog and get user selection
	ret = __dialog.select( 'Select Addon Type', listAddonType )
	# check and perform action based on user selection
	if ret == 0:
		getPlugIn()
	elif ret == 1:
		getScript()
	elif ret == 2:
		reset()
	else:
		# handle invalid selection and exit; nevertheless, notify the user what happened
		xebi('Xbmc.Notification(Xbox Addon Shortcut, Selection Cancelled!)')
		
if __name__ == '__main__':
	main()
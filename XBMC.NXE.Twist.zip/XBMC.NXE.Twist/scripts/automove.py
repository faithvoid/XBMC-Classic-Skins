import xbmc

while True:
	if xbmc.getCondVisibility( "Container(300).HasFocus(2)" ): 
		xbmc.executebuiltin('XBMC.Control.Move(302,1)')
		xbmc.executebuiltin('XBMC.Control.Move(304,1)')
	if xbmc.getCondVisibility( "Container(300).HasFocus(3)" ): 
		xbmc.executebuiltin('XBMC.Control.Move(404,1)')
	if xbmc.getCondVisibility( "Container(300).HasFocus(4)" ): 
		xbmc.executebuiltin('XBMC.Control.Move(504,1)')
	if xbmc.getCondVisibility( "Container(300).HasFocus(6)" ): 
		xbmc.executebuiltin('XBMC.Control.Move(704,1)')
	xbmc.sleep( 4000 )
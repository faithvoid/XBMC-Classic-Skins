import xbmc
from xbmcgui import Window
from urllib import quote_plus, unquote_plus
import re
import sys
import os


class Main:
    # grab the home window
    WINDOW = Window( 10000 )	
	
    def _get_media( self, path, file ):
        # set default values
        play_path = fanart_path = thumb_path = path + file
        # we handle stack:// media special
        if ( file.startswith( "stack://" ) ):
            play_path = fanart_path = file
            thumb_path = file[ 8 : ].split( " , " )[ 0 ]
        # we handle rar:// and zip:// media special
        if ( file.startswith( "rar://" ) or file.startswith( "zip://" ) ):
            play_path = fanart_path = thumb_path = file
        # return media info
        return xbmc.getCacheThumbName( thumb_path ), xbmc.getCacheThumbName( fanart_path ), play_path

    def __init__( self ):
		
		self.TOTAL = 0
		
		keyboard = xbmc.Keyboard( '', 'Search XBMC', False )     
		keyboard.doModal()
		
		if ( keyboard.isConfirmed() ):         
			self.__searchString = keyboard.getText() 

			# format our records start and end
			xbmc.executehttpapi( "SetResponseFormat()" )
			xbmc.executehttpapi( "SetResponseFormat(OpenRecord,%s)" % ( "<record>", ) )
			xbmc.executehttpapi( "SetResponseFormat(CloseRecord,%s)" % ( "</record>", ) )
			
			# fetch media info
			self._fetch_movie_info()
			self._fetch_tvshow_info()
			self._fetch_music_info()
	
    def _fetch_movie_info( self ):
		# unplayed added
		sql_movies = 'SELECT c00, c05, c07, c11, c12, c14, c19, strFileName, strPath FROM movieview WHERE c00 LIKE "%' + self.__searchString + '%"'
		xbmc.log( 'XBox.Search.SQL: ' + str( sql_movies ) , level=xbmc.LOGDEBUG )
		# query the database
		movies_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_movies ), )
        # separate the records
		movies = re.findall( "<record>(.+?)</record>", movies_xml, re.DOTALL )
		xbmc.log( 'XBox.Search.Result.Movies ===================================================================' , level=xbmc.LOGDEBUG )
		
        # enumerate thru our records and set our properties
		for count, movie in enumerate( movies ):
            # separate individual fields
			fields = re.findall( "<field>(.*?)</field>", movie, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 0 ]  , level=xbmc.LOGDEBUG )
			
			# set properties
            #self.WINDOW.setProperty( "LatestMovie.%d.Title" % ( count + 1, ), fields[ 0 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Rating" % ( count + 1, ), fields[ 1 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Year" % ( count + 1, ), fields[ 2 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.RunningTime" % ( count + 1, ), fields[ 3 ] )
			
            #self.WINDOW.setProperty( "LatestMovie.%d.Mpaa" % ( count + 1, ), fields[ 4 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Genre" % ( count + 1, ), fields[ 5 ] )
			
			# get cache names of path to use for thumbnail/fanart and play path
            #thumb_cache, fanart_cache, play_path = self._get_media( fields[ 8 ], fields[ 7 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Path" % ( count + 1, ), ( play_path, fields[ 6 ], )[ fields[ 6 ] != "" and self.PLAY_TRAILER ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Trailer" % ( count + 1, ), fields[ 6 ] )
            #self.WINDOW.setProperty( "LatestMovie.%d.Fanart" % ( count + 1, ), "special://profile/Thumbnails/Video/%s/%s" % ( "Fanart", fanart_cache, ) )
            # initial thumb path
            #thumb = "special://profile/Thumbnails/Video/%s/%s" % ( thumb_cache[ 0 ], thumb_cache, )
            # if thumb does not exist use an auto generated thumb path
            #if ( not os.path.isfile( xbmc.translatePath( thumb ) ) ):
            #    thumb = "special://profile/Thumbnails/Video/%s/auto-%s" % ( thumb_cache[ 0 ], thumb_cache, )
            #self.WINDOW.setProperty( "LatestMovie.%d.Thumb" % ( count + 1, ), thumb )

    def _fetch_tvshow_info( self ):
		sql_episodes = 'SELECT strTitle, c00, c12, c13, c03, strFileName, strPath FROM episodeview WHERE c00 LIKE "%' + self.__searchString + '%"'
		xbmc.log( 'XBox.Search.SQL: ' + str( sql_episodes ) , level=xbmc.LOGDEBUG )
		# query the database
		episodes_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_episodes ), )
		# separate the records
		episodes = re.findall( "<record>(.+?)</record>", episodes_xml, re.DOTALL )
		xbmc.log( 'XBox.Search.Result.Episodes ================================================================='  , level=xbmc.LOGDEBUG )

		# enumerate thru our records and set our properties
		for count, episode in enumerate( episodes ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", episode, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 1 ] + " TvShow: " + fields[0] , level=xbmc.LOGDEBUG )
			# set properties
			#self.WINDOW.setProperty( "LatestEpisode.%d.ShowTitle" % ( count + 1, ), fields[ 0 ] )
			#xbmc.log( 'XBox.Featured.Media: ' + fields[ 0 ], level=xbmc.LOGDEBUG )

			#self.WINDOW.setProperty( "LatestEpisode.%d.EpisodeTitle" % ( count + 1, ), fields[ 1 ] )
			#xbmc.log( 'XBox.Featured.Media: ' + fields[ 1 ], level=xbmc.LOGDEBUG )

			#self.WINDOW.setProperty( "LatestEpisode.%d.EpisodeNo" % ( count + 1, ), "S%02dE%02d" % ( int( fields[ 2 ] ), int( fields[ 3 ] ), ) )
			#self.WINDOW.setProperty( "LatestEpisode.%d.Rating" % ( count + 1, ), fields[ 4 ] )
			# get cache names of path to use for thumbnail/fanart and play path
			#thumb_cache, fanart_cache, play_path = self._get_media( fields[ 6 ], fields[ 5 ] )
			#self.WINDOW.setProperty( "LatestEpisode.%d.Path" % ( count + 1, ), play_path )
			#self.WINDOW.setProperty( "LatestEpisode.%d.Fanart" % ( count + 1, ), "special://profile/Thumbnails/Video/%s/%s" % ( "Fanart", fanart_cache, ) )
			# initial thumb path
			#thumb = "special://profile/Thumbnails/Video/%s/%s" % ( thumb_cache[ 0 ], thumb_cache, )
			# if thumb does not exist use an auto generated thumb path
			#if ( not os.path.isfile( xbmc.translatePath( thumb ) ) ):
			#	thumb = "special://profile/Thumbnails/Video/%s/auto-%s" % ( thumb_cache[ 0 ], thumb_cache, )
			#self.WINDOW.setProperty( "LatestEpisode.%d.Thumb" % ( count + 1, ), thumb )

    def _fetch_music_info( self ):
		# random music sql statement
		sql_music = 'SELECT strTitle, iYear, strArtist, strAlbum, strGenre, strPath, strFileName, strThumb FROM songview WHERE strTitle LIKE "%' + self.__searchString + '%"'
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		xbmc.log( 'XBox.Search.Result.Songs ==================================================================== ' , level=xbmc.LOGDEBUG )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 0 ]  , level=xbmc.LOGDEBUG )
			# set properties
		#	self.WINDOW.setProperty( "LatestSong.%d.Title" % ( count + 1, ), fields[ 0 ] )
		#	self.WINDOW.setProperty( "LatestSong.%d.Year" % ( count + 1, ), fields[ 1 ] )
		#	self.WINDOW.setProperty( "LatestSong.%d.Artist" % ( count + 1, ), fields[ 2 ] )
		#	self.WINDOW.setProperty( "LatestSong.%d.Album" % ( count + 1, ), fields[ 3 ] )
		#	path = fields[ 5 ]
		#	path += fields[ 6 ]
		#	self.WINDOW.setProperty( "LatestSong.%d.Path" % ( count + 1, ), path )
		#	self.WINDOW.setProperty( "LatestSong.%d.Thumb" % ( count + 1, ), fields[ 7 ] )

		# random albums sql statement (where the album name is not blank)
		sql_music = 'SELECT idAlbum, strAlbum, iYear, strArtist, strThumb FROM albumview WHERE strAlbum LIKE "%' + self.__searchString + '%"'
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		xbmc.log( 'XBox.Search.Result.Albums =================================================================== ' , level=xbmc.LOGDEBUG )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 1 ]  , level=xbmc.LOGDEBUG )
			# set properties
			#self.WINDOW.setProperty( "RandomAlbum.%d.ID" % ( count + 1, ), fields[ 0 ] )
			#self.WINDOW.setProperty( "RandomAlbum.%d.Title" % ( count + 1, ), fields[ 1 ] )
			#self.WINDOW.setProperty( "RandomAlbum.%d.Year" % ( count + 1, ), fields[ 2 ] )
			#self.WINDOW.setProperty( "RandomAlbum.%d.Artist" % ( count + 1, ), fields[ 3 ] )
			#self.WINDOW.setProperty( "RandomAlbum.%d.Thumb" % ( count + 1, ), fields[ 4 ] )
			
if ( __name__ == "__main__" ):
    Main()


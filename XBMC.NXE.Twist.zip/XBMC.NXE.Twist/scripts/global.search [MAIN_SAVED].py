import xbmc
from xbmcgui import Window
from urllib import quote_plus, unquote_plus
import re
import sys
import os


class Main:
    # grab the home window
    WINDOW = Window( 10000 )	

    def __init__( self ):
	
		keyboard = xbmc.Keyboard( '', 'Search XBMC', False )     
		keyboard.doModal()     
		if ( keyboard.isConfirmed() ):         
			self.__searchString = keyboard.getText() 

			# format our records start and end
			xbmc.executehttpapi( "SetResponseFormat()" )
			xbmc.executehttpapi( "SetResponseFormat(OpenRecord,%s)" % ( "<record>", ) )
			xbmc.executehttpapi( "SetResponseFormat(CloseRecord,%s)" % ( "</record>", ) )
			# fetch media info
			self._fetch_movie_info()
			self._fetch_tvshow_info()
			self._fetch_music_info()
	
    def _fetch_movie_info( self ):
		# database sql statement
		sql_movies = 'SELECT c00, c05, c07, c11, c12, c14, c19, strFileName, strPath FROM movieview WHERE c00 LIKE "%' + self.__searchString + '%"'
		# query the database
		movies_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_movies ), )
        # separate the records
		movies = re.findall( "<record>(.+?)</record>", movies_xml, re.DOTALL )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		xbmc.log( 'XBox.Search.Result.Movies' , level=xbmc.LOGDEBUG )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		
        # enumerate thru our records and set our properties
		for count, movie in enumerate( movies ):
            # separate individual fields
			fields = re.findall( "<field>(.*?)</field>", movie, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 0 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'XBox.Search.Result.Year: ' + str((count + 1)) + ' - ' + fields[ 2 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'XBox.Search.Result.Time: ' + str((count + 1)) + ' - ' + fields[ 3 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'XBox.Search.Result.Genre: ' + str((count + 1)) + ' - ' + fields[ 5 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'XBox.Search.Result.File: ' + str((count + 1)) + ' - ' + fields[ 7 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'XBox.Search.Result.Path: ' + str((count + 1)) + ' - ' + fields[ 8 ]  , level=xbmc.LOGDEBUG )
			xbmc.log( 'Xbox.Search ' , level=xbmc.LOGDEBUG )

    def _fetch_tvshow_info( self ):
		# database sql statement
		sql_episodes = 'SELECT strTitle, c00, c12, c13, c03, strFileName, strPath FROM episodeview WHERE c00 LIKE "%' + self.__searchString + '%"'
		# query the database
		episodes_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_episodes ), )
		# separate the records
		episodes = re.findall( "<record>(.+?)</record>", episodes_xml, re.DOTALL )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		xbmc.log( 'XBox.Search.Result.Episodes '  , level=xbmc.LOGDEBUG )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		# enumerate thru our records and set our properties
		for count, episode in enumerate( episodes ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", episode, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 1 ] + " TvShow: " + fields[0] , level=xbmc.LOGDEBUG )

    def _fetch_music_info( self ):
		# database sql statement
		sql_music = 'SELECT strTitle, iYear, strArtist, strAlbum, strGenre, strPath, strFileName, strThumb FROM songview WHERE strTitle LIKE "%' + self.__searchString + '%"'
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		xbmc.log( 'XBox.Search.Result.Songs ' , level=xbmc.LOGDEBUG )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 0 ]  , level=xbmc.LOGDEBUG )

		# database sql statement
		sql_music = 'SELECT idAlbum, strAlbum, iYear, strArtist, strThumb FROM albumview WHERE strAlbum LIKE "%' + self.__searchString + '%"'
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		xbmc.log( 'XBox.Search.Result.Albums ' , level=xbmc.LOGDEBUG )
		xbmc.log( '============================================================================================='  , level=xbmc.LOGDEBUG )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			xbmc.log( 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 1 ]  , level=xbmc.LOGDEBUG )
			
if ( __name__ == "__main__" ):
    Main()


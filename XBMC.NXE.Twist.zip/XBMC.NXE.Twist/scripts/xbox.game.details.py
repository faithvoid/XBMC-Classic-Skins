#-------------------------------------------------------------------------------
# Name:   	xbox.game.details.py()
# Purpose:	To get the local details for a given xbox title
# Author:	Dom DXecutioner
# Created:	06.27.2012
# Updated:	06.27.2012
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import os,re
import xbmc
import xbmcgui
from BeautifulSoup import *

__gamePath__ = xbmc.getInfoLabel( 'Skin.String(Xbox.Game.Path)' )
__gameXmlFile__ = __gamePath__ + '_default/default.xml'

__window = xbmcgui.Window( xbmcgui.getCurrentWindowId() )

# general variables
__addOnName__ = "XBMC.NXE.Twist"
__dataPath__ = os.path.join('special://home/skin/', __addOnName__ )

def xebi(td):
	log( 'Skin.Setting : ' + td )
	xbmc.executebuiltin( td )

def log(msg):
	xbmc.log( 'XBox.Game.Details: ' + str( msg ), level=xbmc.LOGDEBUG )

def GetGTNFO():
	
	if os.path.isfile( __gameXmlFile__ ):
		# resolved gamercard url
		print 'Xbox.Game.Details: Game XML File - ' + __gameXmlFile__

		# load file to memory and close connection
		file = open( __gameXmlFile__ )
		fileData = file.read()
		file.close()

		log('Game File: data loaded to memory; will begin querying')

		# get the info
		soupStrainer  = SoupStrainer( "game" )
		beautifulSoup = BeautifulSoup( fileData, soupStrainer )

		#print __gameFile__
		print beautifulSoup.esrb_descriptors.string.replace( '/', '[CR]' )

		print beautifulSoup.platform.string
		print beautifulSoup.title.string
		print beautifulSoup.publisher.string
		print beautifulSoup.developer.string
		print beautifulSoup.genre.string
		print beautifulSoup.esrb.string
		print beautifulSoup.exclusive.string
		print beautifulSoup.released_us.string
		print beautifulSoup.description.string

		__window.setProperty( 'Path', __gamePath__ )
		__window.setProperty( 'Icon', __gamePath__ + 'default.i.tbn' )
		__window.setProperty( 'ESRB', beautifulSoup.esrb.string )
		
		__window.getControl( 100 ).setLabel( beautifulSoup.title.string )
		__window.getControl( 104 ).setLabel( beautifulSoup.esrb_descriptors.string.replace( '/', '[CR]') )
		
		__window.getControl( 106 ).setLabel( beautifulSoup.genre.string )
		__window.getControl( 107 ).setLabel( beautifulSoup.developer.string )
		__window.getControl( 108 ).setLabel( beautifulSoup.publisher.string )
		
		__window.getControl( 109 ).setLabel( beautifulSoup.features_general.string.replace( '/', '[CR]') )
		__window.getControl( 110 ).setLabel( beautifulSoup.features_online.string.replace( '/', '[CR]') )
		
		__window.getControl( 111 ).setText( beautifulSoup.description.string )
				
	else:
		print 'FILE NOT FOUND! - ' + __gameXmlFile__
		
	return

global mode
mode = -1

def main():
	log( '==================================================' )
	
	nfo = GetGTNFO()
	xebi('XBMC.Notification(Xbox Gamer Details, Fetching Complete!)')

	log( '==================================================' )

	
if __name__ == '__main__':
	main()
import xbmc
from xbmcgui import Window
from urllib import quote_plus, unquote_plus
import re
import sys
import os

class Main:
    # grab the home window
    WINDOW = Window( 10000 )

    def _clear_properties( self ):
        # reset Totals property for visible condition
        self.WINDOW.clearProperty( "Database.Totals" )
        # we enumerate thru and clear individual properties in case other scripts set window properties
        for count in range( self.LIMIT ):
            # we clear title for visible condition
            self.WINDOW.clearProperty( "LatestSong.%d.Title" % ( count + 1, ) )

    def _get_media( self, path, file ):
        # set default values
        play_path = fanart_path = thumb_path = path + file
        # we handle stack:// media special
        if ( file.startswith( "stack://" ) ):
            play_path = fanart_path = file
            thumb_path = file[ 8 : ].split( " , " )[ 0 ]
        # we handle rar:// and zip:// media special
        if ( file.startswith( "rar://" ) or file.startswith( "zip://" ) ):
            play_path = fanart_path = thumb_path = file
        # return media info
        return xbmc.getCacheThumbName( thumb_path ), xbmc.getCacheThumbName( fanart_path ), play_path

    def _parse_argv( self ):
        try:
            # parse sys.argv for params
            params = dict( arg.split( "=" ) for arg in sys.argv[ 1 ].split( "&" ) )
        except:
            # no params passed
            params = {}
        # set our preferences
        self.LIMIT = int( params.get( "limit", "5" ) )

    def __init__( self ):
		# parse argv for any preferences
		self._parse_argv()
		# clear properties
		self._clear_properties()
		# format our records start and end
		xbmc.executehttpapi( "SetResponseFormat()" )
		xbmc.executehttpapi( "SetResponseFormat(OpenRecord,%s)" % ( "<record>", ) )
		xbmc.executehttpapi( "SetResponseFormat(CloseRecord,%s)" % ( "</record>", ) )
		# get music info
		self._fetch_totals()
		self._fetch_music_info()

    def _fetch_totals( self ):
        # sql statement for tv songs totals
        sql_totals = "select count(1), count(distinct strAlbum), count(distinct strArtist) from songview"
        totals_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_totals ), )
        music_totals = re.findall( "<field>(.+?)</field>", totals_xml, re.DOTALL )
        # set properties
        self.WINDOW.setProperty( "Music.SongsCount" , music_totals[ 0 ] or "" )
        self.WINDOW.setProperty( "Music.AlbumsCount" , music_totals[ 1 ] or "" )
        self.WINDOW.setProperty( "Music.ArtistsCount" , music_totals[ 2 ] or "" )

    def _fetch_music_info( self ):
		# random music sql statement
		sql_music = "SELECT strTitle, iYear, strArtist, strAlbum, strGenre, strPath, strFileName, strThumb FROM songview ORDER BY RANDOM() limit %d" % ( self.LIMIT, )
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			# set properties
			self.WINDOW.setProperty( "LatestSong.%d.Title" % ( count + 1, ), fields[ 0 ] )
			self.WINDOW.setProperty( "LatestSong.%d.Year" % ( count + 1, ), fields[ 1 ] )
			self.WINDOW.setProperty( "LatestSong.%d.Artist" % ( count + 1, ), fields[ 2 ] )
			self.WINDOW.setProperty( "LatestSong.%d.Album" % ( count + 1, ), fields[ 3 ] )
			path = fields[ 5 ]
			path += fields[ 6 ]
			self.WINDOW.setProperty( "LatestSong.%d.Path" % ( count + 1, ), path )
			self.WINDOW.setProperty( "LatestSong.%d.Thumb" % ( count + 1, ), fields[ 7 ] )

		# random albums sql statement (where the album name is not blank)
		sql_music = "SELECT idAlbum, strAlbum, iYear, strArtist, strThumb FROM albumview WHERE strAlbum <> '' ORDER BY RANDOM() LIMIT %d" % ( self.LIMIT, )
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )			
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			# set properties
			self.WINDOW.setProperty( "RandomAlbum.%d.ID" % ( count + 1, ), fields[ 0 ] )
			self.WINDOW.setProperty( "RandomAlbum.%d.Title" % ( count + 1, ), fields[ 1 ] )
			self.WINDOW.setProperty( "RandomAlbum.%d.Year" % ( count + 1, ), fields[ 2 ] )
			self.WINDOW.setProperty( "RandomAlbum.%d.Artist" % ( count + 1, ), fields[ 3 ] )
			self.WINDOW.setProperty( "RandomAlbum.%d.Thumb" % ( count + 1, ), fields[ 4 ] )			

if ( __name__ == "__main__" ):
    Main()


import xbmc
from xbmcgui import Window
from urllib import quote_plus, unquote_plus
import re
import sys
import os

def log(msg):
    xbmc.log( 'RecentPrograms.Script: ' + str( msg ),level=xbmc.LOGDEBUG )

class Main:
    # grab the home window
    WINDOW = Window( 10000 )

    def _parse_argv( self ):
        try:
            # parse sys.argv for params
            params = dict( arg.split( "=" ) for arg in sys.argv[ 1 ].split( "&" ) )
        except:
            # no params passed
            params = {}
        # set our preferences
        self.LIMIT = int( params.get( "limit", "6" ) )
        self.RECENT = not params.get( "partial", "" ) == "True"
        self.UNPLAYED = params.get( "unplayed", "" ) == "False"

    def __init__( self ):
        # parse argv for any preferences
        self._parse_argv()
        # format our records start and end
        xbmc.executehttpapi( "SetResponseFormat()" )
        xbmc.executehttpapi( "SetResponseFormat(OpenRecord,%s)" % ( "<record>", ) )
        xbmc.executehttpapi( "SetResponseFormat(CloseRecord,%s)" % ( "</record>", ) )
        # fetch media info
        self._fetch_program_info()

    def _fetch_program_info( self ):
		# unplayed games
		sql_movies = "SELECT * FROM files ORDER BY RANDOM() DESC LIMIT %d" % ( self.LIMIT, )
		# query the database
		movies_xml = xbmc.executehttpapi( "QueryProgramDatabase(%s)" % quote_plus( sql_movies ), )
		# separate the records
		movies = re.findall( "<record>(.+?)</record>", movies_xml, re.DOTALL )
		# enumerate thru our records and set our properties
		for count, movie in enumerate( movies ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", movie, re.DOTALL )
			folder = fields[ 1 ]
			# set properties
			self.WINDOW.setProperty( "LatestProgram.%d.Title" % ( count + 1, ), fields[ 3 ] )
			self.WINDOW.setProperty( "LatestProgram.%d.Path" % ( count + 1, ), fields[ 1 ] )
			self.WINDOW.setProperty( "LatestProgram.%d.Folder" % ( count + 1, ), folder.replace("default.xbe","") )
			
			# get cache names of path to use for thumbnail/fanart and play path
			thumb_cache = xbmc.getCacheThumbName( fields[ 1 ] )
			# initial thumb path
			thumb = "special://profile/Thumbnails/Programs/%s/%s" % ( thumb_cache[ 0 ], thumb_cache, )
			
			log( '=================================================================================' )
			log( count + 1 )
			log( 'TITLE: ' + fields[3] )
			log( 'PATH: ' + fields[1] )
			log( 'FOLDER: ' + folder.replace("default.xbe","") )
			log( 'THUMB_CACHE_NAME: ' + thumb_cache )
			log( 'THUMB_CACHE_PATH: ' + thumb )
			log( 'THUMB_CACHE_PATH_TRANSLATED: ' + xbmc.translatePath( thumb ) )
			log( '=================================================================================' )
			
			# if thumb does not exist use an auto generated thumb path
			if ( not os.path.isfile( xbmc.translatePath( thumb ) ) ):
				thumb = "special://profile/Thumbnails/Programs/%s/auto-%s" % ( thumb_cache[ 0 ], thumb_cache, )
			self.WINDOW.setProperty( "LatestProgram.%d.Thumb" % ( count + 1, ), thumb )

if ( __name__ == "__main__" ):
    Main()


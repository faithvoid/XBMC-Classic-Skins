#-------------------------------------------------------------------------------
# Name:   	xbox.game.details.py()
# Purpose:	To get the local details for a given xbox title
# Author:	Dom DXecutioner
# Created:	06.27.2012
# Updated:	06.27.2012
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import xbmc
import xbmcgui
import sys
import os
from BeautifulSoup import *

__gamePath = xbmc.getInfoLabel( 'Skin.String(Xbox.Game.Path)' )
__gameXmlFile = __gamePath + '_default\default.xml'



class GUI( xbmcgui.WindowXML ):
	def onInit(self):
		print '|==================================|'
		print 'onInit(): Initialized!' 
		
		self.GAME_PATH = xbmc.getInfoLabel( 'Skin.String(Xbox.Game.Path)' )
		self.GAME_XML_FILE = self.GAME_PATH + '_default\default.xml'
		self.getDetails()
	
	def onFocus(self, controlID):
		print '|==================================|'
		print 'onFocus(): Initialized!'
	
	def onClick( self, controlId ):
		print '|==================================|'
		print 'onClick(): Initialized!'
	
	def getDetails( self ):
		print '|==================================|'
		print 'getDetails(): Initialized!' 

		# load file to memory and close connection
		file = open( self.GAME_XML_FILE )
		fileContent = file.read()
		file.close()
		
		# get the info
		soupStrainer  = SoupStrainer( "game" )
		game = BeautifulSoup( fileContent, soupStrainer )
				
		print self.GAME_PATH
		
		self.setProperty( 'Path', str(self.GAME_PATH) )
		self.setProperty( 'Icon', self.GAME_PATH + 'default.i.tbn' )
		self.setProperty( 'ESRB', game.esrb.string )
		
		self.getControl( 98 ).setLabel( self.GAME_PATH )
		self.getControl( 99 ).setLabel( game.esrb.string )
		
		print game.platform.string
		print game.title.string
		print game.publisher.string
		print game.developer.string
		print game.genre.string
		print game.esrb.string
		print game.exclusive.string
		print game.released_us.string
		print game.description.string
		
		self.getControl( 100 ).setLabel( game.title.string )
		self.getControl( 104 ).setLabel( game.esrb_descriptors.string.replace( '/', '[CR]') )
		self.getControl( 105 ).setLabel( game.released_us.string )
		
		self.getControl( 106 ).setLabel( game.genre.string )
		self.getControl( 107 ).setLabel( game.developer.string )
		self.getControl( 108 ).setLabel( game.publisher.string )
		
		self.getControl( 109 ).setLabel( game.features_general.string.replace( '/', '[CR]') )
		self.getControl( 110 ).setLabel( game.features_online.string.replace( '/', '[CR]') )
		
		self.getControl( 111 ).setText( game.description.string )
		
if ( __name__ == "__main__" ):
	
	print '|==================================|'
	print 'xbox.game.details.py: script started'
	print 'game.path ' + __gamePath
	print 'game.xml.file: ' + __gameXmlFile
	
	if os.path.isfile( __gameXmlFile ):         
		
		print 'game.xml.file: found xml file'
		
		w = GUI( '_script.game.details.xml', os.getcwd() )
		w.doModal()
	
		del w

	print 'xbox.game.details.py: script ended'
	print '|==================================|'

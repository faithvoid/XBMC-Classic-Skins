import xbmc
import xbmcgui
from urllib import quote_plus, unquote_plus
import re
import sys
import os

_searchString = ''

class GUI( xbmcgui.WindowXML ):
	def onInit(self):
		
		self._search_movie()
		self._search_tv_shows()
		self._search_songs()
		print "onInit(): Window Initialized"
	
	def onFocus(self, controlID):
		print "onFocus(): Initialized"
	
	def _search_movie( self ):
		print "_search_movie(): Initialized"
		# database sql statement
		sql_movies = 'SELECT c00, c05, c07, c11, c12, c14, c19, strFileName, strPath FROM movieview WHERE c00 LIKE "%high%"' #+ _searchString + '%"'
		# query the database
		movies_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_movies ), )
		# separate the records
		movies = re.findall( "<record>(.+?)</record>", movies_xml, re.DOTALL )
		
		# enumerate thru our records and set our properties
		for count, movie in enumerate( movies ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", movie, re.DOTALL )

			# get cache names of path to use for thumbnail/fanart and play path
			thumb_cache, fanart_cache, play_path = self._get_media( fields[ 8 ], fields[ 7 ] )
			thumb = "special://profile/Thumbnails/Video/%s/%s" % ( thumb_cache[ 0 ], thumb_cache, )
			
			list_item = xbmcgui.ListItem( 'In movies:[CR]' + fields[0], fields[ 2 ], thumb, thumb )
			self.addItem( list_item )
			item = self.getListItem(count)
			item.setInfo( 'video', { 'Mpaa': fields[ 4 ], 'Year': int( fields[ 2 ] ), 'Genre': fields[ 4 ], 'Duration': fields[ 3 ] } )
			item.setProperty( 'rating', 'rating' + str (int( float( fields[ 1 ] ) ) / 2 ) + '.png' )

			print 'Xbox.Search '
			print 'XBox.Search.Result.Title: ' + str((count + 1)) + ' - ' + fields[ 0 ]
			print 'XBox.Search.Result.Year: ' + str((count + 1)) + ' - ' + fields[ 2 ]
			print 'XBox.Search.Result.Time: ' + str((count + 1)) + ' - ' + fields[ 3 ]
			print 'XBox.Search.Result.Genre: ' + str((count + 1)) + ' - ' + fields[ 5 ]
			print 'XBox.Search.Result.File: ' + str((count + 1)) + ' - ' + fields[ 7 ]
			print 'XBox.Search.Result.Path: ' + str((count + 1)) + ' - ' + fields[ 8 ]
			print 'Xbox.Search '

	def _search_tv_shows( self ):
		print "_search_tv_shows(): Initialized"
		# sql statment
		sql_episodes = 'SELECT strTitle, c00, c12, c13, c03, strFileName, strPath FROM episodeview WHERE c00 LIKE "%high%"'
		# query the database
		episodes_xml = xbmc.executehttpapi( "QueryVideoDatabase(%s)" % quote_plus( sql_episodes ), )
		# separate the records
		episodes = re.findall( "<record>(.+?)</record>", episodes_xml, re.DOTALL )
		# enumerate thru our records and set our properties
		for count, episode in enumerate( episodes ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", episode, re.DOTALL )

			# get cache names of path to use for thumbnail/fanart and play path
			thumb_cache, fanart_cache, play_path = self._get_media( fields[ 6 ], fields[ 5 ] )
			thumb = "special://profile/Thumbnails/Video/%s/%s" % ( thumb_cache[ 0 ], thumb_cache, )
			print thumb			
			
			list_item = xbmcgui.ListItem( 'In Episodes:[CR]' + fields[0], fields[ 2 ], thumb, thumb )
			self.addItem( list_item )

	def _search_songs( self ):
		print "_search_songs(): Initialized"
		# random music sql statement
		sql_music = 'SELECT strTitle, iYear, strArtist, strAlbum, strGenre, strPath, strFileName, strThumb FROM songview WHERE strTitle LIKE "%high%"'
		# query the database
		music_xml = xbmc.executehttpapi( "QueryMusicDatabase(%s)" % quote_plus( sql_music ), )
		# separate the records
		items = re.findall( "<record>(.+?)</record>", music_xml, re.DOTALL )
		# enumerate thru our records and set our properties
		for count, item in enumerate( items ):
			# separate individual fields
			fields = re.findall( "<field>(.*?)</field>", item, re.DOTALL )
			
			# set properties
			list_item = xbmcgui.ListItem( 'In Songs:[CR]' + fields[0], fields[ 1 ], fields[ 7 ], fields[ 7 ] )
			self.addItem( list_item )

	def _get_media( self, path, file ):
		print '_get_media(): Intialized'
		# set default values
		play_path = fanart_path = thumb_path = path + file
		# we handle stack:// media special
		if ( file.startswith( "stack://" ) ):
			play_path = fanart_path = file
			thumb_path = file[ 8 : ].split( " , " )[ 0 ]
		# we handle rar:// and zip:// media special
		if ( file.startswith( "rar://" ) or file.startswith( "zip://" ) ):
			play_path = fanart_path = thumb_path = file
		# return media info
		return xbmc.getCacheThumbName( thumb_path ), xbmc.getCacheThumbName( fanart_path ), play_path
			
if ( __name__ == "__main__" ):
	#Main()

	keyboard = xbmc.Keyboard( '', 'Search XBMC', False )     
	keyboard.doModal()     
	if ( keyboard.isConfirmed() ):         
		_searchString = keyboard.getText() 

		# format our records start and end
		xbmc.executehttpapi( "SetResponseFormat()" )
		xbmc.executehttpapi( "SetResponseFormat(OpenRecord,%s)" % ( "<record>", ) )
		xbmc.executehttpapi( "SetResponseFormat(CloseRecord,%s)" % ( "</record>", ) )

		w = GUI( '_globalSearch.xml', os.getcwd() )
		w.doModal()
	
		del w

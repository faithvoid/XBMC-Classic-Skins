#-------------------------------------------------------------------------------
# Name:   	xbox.getplugin.py()
# Purpose:	To get custom shortcut plugin or script
# Author:	Dom DXecutioner
# Created:	03.25.2012
# Updated:	04.05.2012
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import xbmc
import xbmcgui
import re
import os
import sys

# object
__window = xbmcgui.Window( xbmcgui.getCurrentWindowId() )
#__window = xbmcgui.Window( 1113 )
__dialog = xbmcgui.Dialog()

# constants
__addonPluginDefault__ = 'special://home/plugins/'
__addonScriptDefault__ = 'special://home/scripts'

# general variables
__shortcutString__ = 'home.addon.shortcut'

__addonShortcutIndex__ = __window.getProperty( __shortcutString__ + '.index' )
__addonShortcutType__ = __window.getProperty( __shortcutString__ + '.type' )
__addonShortcutCategory__ = __window.getProperty( __shortcutString__ + '.category' )

	
def xebi(td):
	log( 'Skin.Setting : ' + td )
	xbmc.executebuiltin( td )

def log(msg):
	xbmc.log( 'XBox.Addon.Shortcut: ' + str( msg ), level=xbmc.LOGDEBUG )
		
def getScript():
	log( 'Selected Type: Script' )
	
	# open the dialog window with the scripts folder as the default directory
	__addonPath__ = __dialog.browse(0,'XBMC Script', 'files', '', False, False, __addonScriptDefault__ )
	# get the asbolute path of the selected directory; if simply use "os.path.basename( __addonPath__ ), it will not work; something to do with trailing slash "/"
	__addonFolder__ = os.path.basename( os.path.abspath( __addonPath__ ) )
	# add the shortcut onclick event + "default.py"; otherwise this will fail!
	xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',Xbmc.RunScript(' + __addonPath__ + 'default.py))' )
	xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.folder,' + __addonFolder__ + ')' )
	# get the default icon
	getIcon( __addonPath__ )
			
def getPlugIn():
	log( 'Addon Type    : Plugin' )
	log( 'Addon Category: ' + __addonShortcutCategory__ )
	
	# check for valid category selection
	if __addonShortcutCategory__ in ( 'music', 'pictures', 'programs', 'video', 'weather' ):
		# assume valid selection; open browser dialog in default directory based on user category selection
		__addonPath__ = __dialog.browse(0,'XBMC Plugin', 'files', '', False, False, __addonPluginDefault__ + __addonShortcutCategory__ )
		# test for valid folder
		if not __addonPath__ == __addonPluginDefault__ + __addonShortcutCategory__:
			# assume a valid selection has been made since it does not match the default location
			__addonFolder__ = os.path.basename( os.path.abspath( __addonPath__ ) )
			# add the shortcut onclick event + "default.py"; otherwise this will fail!
			if __addonShortcutCategory__ == 'music': xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',Xbmc.ActivateWindow(MusicLibrary,plugin://music/' + __addonFolder__ + '))' )
			if __addonShortcutCategory__ == 'programs': xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',Xbmc.ActivateWindow(Programs,plugin://programs/' + __addonFolder__ + '))' )
			if __addonShortcutCategory__ == 'video': xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.onclick.' + __addonShortcutIndex__ + ',Xbmc.ActivateWindow(VideoLibrary,plugin://video/' + __addonFolder__ + '))' )
			
			xebi( 'xbmc.notification(xbox: addon category,' + __addonFolder__ + ')' )
			
			xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.folder,' + __addonFolder__ + ')' )
			# get default icon 
			getIcon( __addonPath__ )
		else:
			# assume user has cancelled since selection matches default location and notify user
			xebi('XBMC.Notification(Xbox Plugin,Invalid or Cancelled Selection!)')
	else:
		# assume a category has been made by user or incorrect parameters by skinner
		xebi('XBMC.Notification(Xbox Plugin,Addon Category Required!)')

def getIcon(path):
	__addonIconTBN__ = path + "default.tbn"
	__addonIconPNG__ = path + "default.png"	

	if os.path.isfile( __addonIconTBN__ ):
		xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',' + __addonIconTBN__ + ')' )
	elif os.path.isfile ( __addonIconPNG__ ):
		xebi( 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',' + __addonIconPNG__ + ')' )

	xebi('XBMC.Notification(Xbox Addon,' + 'XBMC.Skin.SetString(' + __shortcutString__ + '.icon.' + __addonShortcutIndex__ + ',png|tbn)' + ')')
		
global mode
mode = -1

def main():
	log( '==================================================' )	
	
	log( 'Current Window: ' + str( xbmcgui.getCurrentWindowId() ) )
	log( 'Addon Index   : ' + __addonShortcutIndex__ )
		
	if __addonShortcutType__ == 'script':
		# handle script selection
		getScript()
	elif __addonShortcutType__ == 'plugin':
		# handle plugin selection
		getPlugIn()
	else:
		# handle invalid selection and exit; nevertheless, notify the user what happened
		xebi('Xbmc.Notification(Xbox Addon Shortcut, Addon Type Required!)')
			
if __name__ == '__main__':
	main()
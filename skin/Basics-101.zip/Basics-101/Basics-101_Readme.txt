The Basics-101 skin is based on the graphics that Mikebeecham
did for his Pandora skin mockups. 
(it uses its icons, its background image and color scheme). 
And they look great all credit to Mikebeecham for a great effort

!!!Please note this is not the Pandora skin.!!! 

It is a skin that I intend to use as my main media center skin
on Linux port of XBMC and is really only designed originally for
media playback only not games play.

I took ideas from a few other skins that I have done or liked
Its very xTV in style and also has a few touches of Vision thrown
in for good measure (side bars and nav sounds)

This skin is for 720p 1080i only though I did include a basic
Pal16x9 font file but the icon images look real blocky edges 
scaled down to that size
.
Its simple has no fancy view types (except Media Info) or
Animations It has large readable font (xbox people may need to
size it down a little it was meant for my 1360x768 rez of my
TV that Linux full screen uses)

If you got the premade skins instead of from the SVN Ignore this.
As I said it was made for Linux so by default there are no links
to "Programs" section you will need to run Build_for_Xbox.bat if 
you want to use it on the xbox. Other wise run Build_for_Media.bat

!!! This skin has no KAI Stuff in it at all if you use KAI in XBMC
pick another skin This one wont work for you  !!!

It designed to be super mouse friendly (its for Linux remember)
And has 1 Setting in the Settings Page side bar that will add some
extra mouse features like moving the mouse over the right edge
will open the shutdown menu (right click needed to close) and also
while media is playing a hotspot will be in the middle of the 
bottom of the screen that will open Player Controls so you can 
FF RW Stop Pause etc... with the mouse. (right click needed to close)

I recommend that you up your icon cache to at least 384 anything 
smaller and list view looks pretty average. But again like I said
its for Linux xbox might lag a little with that size cache.

Enjoy the skin 

Jezz_X

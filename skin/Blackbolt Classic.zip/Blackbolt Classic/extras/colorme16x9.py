# ColorMe - Changes the colors of fonts in Blackbolt Classic
# Originally Made by Donno for MC360 converted to use with BBC by Jezz_X
# All credit goes to Donno

import xbmcgui, re, xbmc
from os import path, listdir
filepath = "Q:\\Skin\\Blackbolt Classic\\PAL16x9\\includes.xml"
filepathCT = "Q:\\Skin\\Blackbolt Classic\\ColorThemes\\"
rs = '<include name="%s"><%s>%s</%s></include> <!--'
def fileopen(f):
    fs = open(f,"r")
    data = fs.read()
    fs.close()
    return data

def WriteFile(f,data):
    fs = open(f,"w")
    fs.write(data)
    fs.close()

def ReadColorSettings(fp,data):
    configdata = fileopen(fp)
    configdata = configdata.split("\n")
    for i in configdata:
        cfd = i.split("=")
        if len(cfd) == 3:
            data = changeItem(data,cfd[0],cfd[1],cfd[2])
    return data

def Default(data):
    data = changeItem(data,"shadow-black","FF000000","shadowcolor")
    data = changeItem(data,"textcolor-white","DDFFFFFF","textcolor")
    data = changeItem(data,"textcolor-white2","D0FFFFFF","textcolor2")
    data = changeItem(data,"textcolor-black","FF000000","textcolor")
    data = changeItem(data,"textcolor-yellow","FFE7FF00","textcolor")
    data = changeItem(data,"textcolor-green","FF9FCA4F","textcolor")
    data = changeItem(data,"textcolor-green2","FF80C234","textcolor")
    data = changeItem(data,"textcolor-selected","FF9FCA4F","selectedcolor")
    data = changeItem(data,"textcolor-selected2","FF9FCA4F","selectedcolor2")
    data = changeItem(data,"textcolor-spincontrol","FFE7FF00","spincolor")
    data = changeItem(data,"textcolor-rsstitle","FF9FCA4F","titlecolor")
    data = changeItem(data,"textcolor-rssheadline","FF80C234","headlinecolor")
    return data

def Moonlight(data):
    data = changeItem(data,"textcolor-yellow","FF00eaff","textcolor")
    data = changeItem(data,"textcolor-green","FF4fbaca","textcolor")
    data = changeItem(data,"textcolor-green2","FF34a9c2","textcolor")
    data = changeItem(data,"textcolor-selected","FF34a9c2","selectedcolor")
    data = changeItem(data,"textcolor-selected2","FF34a9c2","selectedcolor2")
    data = changeItem(data,"textcolor-spincontrol","FF00eaff","spincolor")
    data = changeItem(data,"textcolor-rsstitle","FF4fbaca","titlecolor")
    data = changeItem(data,"textcolor-rssheadline","FF34a9c2","headlinecolor")
    return data

def Farenheit(data):
    data = changeItem(data,"textcolor-yellow","FFffd600","textcolor")
    data = changeItem(data,"textcolor-green","FFca4f4f","textcolor")
    data = changeItem(data,"textcolor-green2","FFae1a1a","textcolor")
    data = changeItem(data,"textcolor-selected","FFfff000","selectedcolor")
    data = changeItem(data,"textcolor-selected2","FFfff000","selectedcolor2")
    data = changeItem(data,"textcolor-spincontrol","FFfff000","spincolor")
    data = changeItem(data,"textcolor-rsstitle","FFca4f4f","titlecolor")
    data = changeItem(data,"textcolor-rssheadline","FFae1a1a","headlinecolor")
    return data

def changeItem(data,item,newcolor,type):
    rsm = rs % (item,type,"(.*)",type)
    newstr = rs % (item,type,newcolor,type)
    data = re.compile(rsm, re.IGNORECASE).sub( newstr, data)
    #t = re.compile(rsm, re.IGNORECASE).findall(data) # For reading
    return data
def CTList(optionlist):
    if path.exists(filepathCT):
        ctlist = listdir(filepathCT)
        for x in ctlist:
            if x[-4:] == ".cof":
                optionlist.append(x[:-4])
        return optionlist
    return optionlist
def DoStuff(dat):
    optionlist = ["*Read From File*","Default -- Green","Moonlight -- Blue","Farenheit -- Red"]
    optionlist = CTList(optionlist)
    test = xbmcgui.Dialog().select("Select Font Color",optionlist)
    if test == 0:
        fn = xbmcgui.Dialog().browse(1,"Browse for color config","files")
        if fn[-4:] == ".cof" and path.exists(fn):
            dat = ReadColorSettings(fn,dat)
        else:
            xbmcgui.Dialog().ok("Blackbolt Classic","Color remains unchanged")
            return None
    elif test == 1:
        dat = Default(dat)     # << will set back to defaults
    elif test == 2:
        dat = Default(dat)     # << will set back to defaults
        dat = Moonlight(dat)
    elif test == 3:
        dat = Default(dat)     # << will set back to defaults
        dat = Farenheit(dat)
    elif test > 3:
        dat = ReadColorSettings(filepathCT+optionlist[test]+".cof",dat)
    return dat

def main():
    if path.exists(filepath):
        dat = fileopen(filepath)    # loads in the file
        dat = DoStuff(dat)          # Do your thing (show window etc)
        if dat == None:
            return
        WriteFile(filepath,dat)
        xbmcgui.Dialog().ok("Blackbolt Classic","Text Colors Changed","Skin will be reloaded after OK")
        xbmc.executebuiltin('XBMC.ReloadSkin()')
main()

Here goes all the cdArt images, you have to name them:
artist/band-album.png   Ex.( black eyed peas-elephunk.png) Ex.(phil collins-greates hits.png)
here goes the individual folder per artist/band of which you want fanart support, inside each folder 
you have to drop any image you want for that artist/band to show up in the visualization screen.

the folder name have to match the album artist/band name exactly as appear in XBMC.
Icon graphic are made by Mikebeecham Used with permission and 
recolored by me they can be found here
http://mikebeecham.deviantart.com/art/project-PANDORA-dock-icons-66192032
Please ask his permision before you take them for yourself and 
use them in other skins or projects.

Most of the other Graphics are made by NineT9Mustang AKA MattAArron
from the Vision 2 skin (also used with permision) you can find the
Vision2 skin here https://xboxmediacenter.svn.sourceforge.net/svnroot/xboxmediacenter/Vision2

This skin is for 720p and up only though it will still work on lower
just look pretty average,  It also has no 4x3 support

I recommend that you up your icon cache to at least 512 anything 
smaller and list view looks pretty average (Linux XBMC is allready 
bigger than that anyway).

The Backgrounds are ones I found all over the net thanks to google
image search if you own the right to any of them please let me know
The exception is the the Pictures Kitty one that I took from the 
original AEON skin Backpack.http://www.aeonproject.com/

humanist_521_condensed_bt.ttf font was found as a free download
from this site http://www.ufonts.com/search/?q=Humanist

Liberation fonts have their own licence in the fonts directory

Enjoy the skin 

Jezz_X

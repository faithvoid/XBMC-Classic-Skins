SLik - a XBMC skin by Jezz_X
============================

[New Skin] SLik alpha version 0.0.2

SLik is designed to be minimal and follow a theme.

You won't find 100's of media views here just simple down to earth views that concentrate on accessing your media quick and easy and not just showing you all the metadata and not much media 

SLik is not done yet and is still 40% PM3.HD and hasn't had any fine touches put to it, but I think its good to develop stuff in the open and I really need some version control so I can easily undo things.

IF you find/use this skin PLEASE PLEASE PLEASE do not go packaging it up, modding it or releasing your own changes anywhere until I say its done and then it will be in the official XBMC repo.

============================

You can follow SLik development at: http://forum.xbmc.org/showthread.php?t=84756

All credits to Jezz_X!

============================

Because i liked this skin so much and it runs so smoothly on the Xbox i decided to make a XBMC4Xbox compatible version.

Enjoy!


xbs

www.xbmc4xbox.org





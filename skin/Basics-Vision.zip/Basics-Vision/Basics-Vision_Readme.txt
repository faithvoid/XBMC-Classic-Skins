The Basics-Vision skin is combination of 2 skins called Basics-101
and Vision the Icon graphic are made by Mikebeecham and recolored
by me they can be found here
http://mikebeecham.deviantart.com/art/project-PANDORA-dock-icons-66192032
Please ask his permision before you take them for yourself

This skin is for 720p 1080i only though I did include a basic
Pal16x9 font file but the icon images look real blocky edges 
scaled down to that size
.
Its simple has no fancy view types (except Media Info) or
Animations It has large readable font 

!!! This skin has no KAI Stuff in it at all if you use KAI in XBMC
pick another skin This one wont work for you  !!!

I recommend that you up your icon cache to at least 384 anything 
smaller and list view looks pretty average. But again like I said
its for Linux xbox might lag a little with that size cache.

Enjoy the skin 

Jezz_X

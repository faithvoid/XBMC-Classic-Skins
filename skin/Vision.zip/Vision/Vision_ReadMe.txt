Vision Skin for Xbox Media Center
===================================================================
Current Website Download Version: Beta 1
===================================================================
SVN URL: https://svn.sourceforge.net/svnroot/xboxmediacenter/Vision/
===================================================================

INTRODUCTION
=========================================================================================
Hey guys! So it's finally here :)
Keep in mind! This is a public BETA. Not everything will work. There will be bugs. 
There will be things you don't like. There will be things you want to improve.
The reason I am releasing this beta, is to get your feedback! So let me know everything 
you like, or don't like (Hopefully NOTHIN!). A week from this release I will be starting 
the new Themes :) Titanium & ProjectMayhemThree. Other themes will be worked on in my 
spare time, but Titanium & ProjectMayhemThree are my top priority :) So keep a lookout 
for these.

The skin supports
=========================================================================================
*Show Current Folder Image
*HDTV (Partially)

HOW TO INSTALL
=========================================================================================
Pretty easy to install, put the VISION directory into your SKIN directory like so:
\XBMC\Skins\Vision\
\XBMC\Skins\Project Mayhem III\
\XBMC\Skins\MC360\

After, go to SETTINGS, APPEARENCE, & Change your Skin to Vision.

USING SKIN
=========================================================================================
Press LEFT for GAMES
Press RIGHT for MEDIA
Press DOWN for My Files/Weather/Etc
While the Chrome Button is in the middle, press A to go to SETTINGS.

DVD and Wide Icons
=========================================================================================
Icon Pack (DVD Posters):
http://putstuff.putfile.com/59797/4488843	
With the release of this beta comes a pack of DVD Posters! 500+ of them. I personally grabbed 
500+ posters: Changed its dimensions to fit into xbmc perfectly. I also edited all of them, I 
took away small fonts you wouldn�t be able to read (Like critic reviews), Quotes from Movie, 
Enlarged the Movie Title if necessary, etc.

Icon Pack (TV Episodes):
http://putstuff.putfile.com/59800/114516
Another Icon pack! This pack includes hundreds episode thumbnails to use with your TV Shows. 
The pack contains around 1,000 Episode Thumbnails from over 15 popular TV Shows. Every Season, 
Every Episode. All renamed correctly with season numbers, episode numbers & the full-correct 
episode name ?. If you plan on using these thumbs Vision, make sure you have your �TV Shows� in 
Wide Icon View, and your �Episodes� in View2 (Movie Poster View)� Because they look slick with 
these settings :D

This is just the beginning of these packs. I will be creating icon packs for a lot more TV Shows 
(Next will be ALL 18 Seasons of The Simpsons, Friends, etc). I will be releasing a DVD Poster pack 
with 1,000+ DVD Posters. So check back in this thread for more information.

CREDITS & THANKS
=========================================================================================
I've gotta give thanks to the following people :

Jezz_X This skin would have NEVER been possible without Jezz_X. I did as much xml as I can, 
and he helped a lot with the rest! 
Modplug If it wasn't for him, I would not have the 
motivation to continue with the skin. He was the only person to ever have a early build of 
the skin to let me know whats wrong and whats right :) 
Donno For always encouraging me by 
lying and saying the skin looked nice.Smokehead For his input on the skin and offering his 
help on the project. 
Spiff For adding some key features I wanted in this skin! This skin would be nothing if 
it wasn't for those features!
Jedi79 For his Kicking-The-Dead-Horse-Jokes-Perfectly
Blackbolt A guy with superior graphic design skills complimenting my work, and going 
completly out of his way in offering the skin a better home :)

And the encouraging feedback from these people : 
Edwinmcdunlap, k@iserex, TheLos, Phistyle, lawdwag0931, manturafs, BecomethemonsteR and his PM's!, 
Nubbs, djdafreund, Sydney30, j4y3m, elitegamer360, kikkegek, wowser, xboxstone, Rotfloljfk and his bucket, 
BlackWraith, rramoutar, dhrandy1, rahulduggal and hiw Sexbox (Maybe the skin and it can get married?), 
unseendemon, isedeasy (no im not gay), Terc, theboxhead, Kautious619, seajay1221 for helping stop the skin 
from exploding, CHI3f for his beta testing of Playstation3 games support, xboxbox451, Horscht for not 
killing anyone, Tiptup300 and his l33t typing skillz, sausje for waiting 1 day 23 hours 18 minutes and 4 
seconds on his best relaxing chair, KSHELLS for waiting like a little kid for christmas, gottastopdrinkin 
for his prediction, dre74, generalnewbie, Andrivious for staying awake every second of the countdown (wow!), 
noob123, SupaDawg, mbay, & a huge thanks to Ana Nicole Smith.

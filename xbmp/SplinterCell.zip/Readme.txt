Notes:

'Splinter Cell Skin' v1.0 for XBMP 2.3
--------------------------------------

Filename: spc.zip

Releasedate: 28.4.2003.
Creator:     Joan Reig

OS:  XBox
Use: Skin for XBox-Mediaplayer 2.3 or higher
-----------------------------------------------------------------------

Info:

- It's a new skin inspired in the Splinter Cell game.
  All graphics in this archive are new.
  This has been tested with the XBMP 2.3 build 24.4.2003
- If you use one of these graphics in your skin, please
  sends a greeting in the readme to me.
  I hope you like my skin.
-----------------------------------------------------------------------

Install:

- Please backup your XBMP Media dir before you start.
- Simply overwrite the existing 'Media' folder.
  Dont't delete any files or folders first !
- In a new skin.xml file i have change only 720X480 4:3 video settings.

Thats all.